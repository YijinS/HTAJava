package chapter3.ex1.capsule;

public class CoursesList {
	   Course[] list;
	    int current ;
}
